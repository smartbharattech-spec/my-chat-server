<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: POST');
header('Access-Control-Allow-Headers: Content-Type');

require_once '../config.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!$data) {
    echo json_encode(['status' => 'error', 'message' => 'No data provided']);
    exit;
}

$expert_id = isset($data['expert_id']) ? (int)$data['expert_id'] : 0;
$name = isset($data['name']) ? trim($data['name']) : '';
$description = isset($data['description']) ? trim($data['description']) : '';
$price = isset($data['price']) ? (float)$data['price'] : 0.00;
$image_url = isset($data['image_url']) ? trim($data['image_url']) : '';
$product_id = isset($data['id']) ? (int)$data['id'] : 0;

if (!$expert_id || !$name) {
    echo json_encode(['status' => 'error', 'message' => 'Expert ID and Product Name are required']);
    exit;
}

try {
    if ($product_id > 0) {
        // Update existing product
        $stmt = $pdo->prepare("UPDATE marketplace_products SET name = ?, description = ?, price = ?, image_url = ? WHERE id = ? AND expert_id = ?");
        $stmt->execute([$name, $description, $price, $image_url, $product_id, $expert_id]);
        $message = "Product updated successfully";
    } else {
        // Create new product
        $stmt = $pdo->prepare("INSERT INTO marketplace_products (expert_id, name, description, price, image_url) VALUES (?, ?, ?, ?, ?)");
        $stmt->execute([$expert_id, $name, $description, $price, $image_url]);
        $message = "Product created successfully";
        $product_id = $pdo->lastInsertId();
    }

    echo json_encode([
        'status' => 'success',
        'message' => $message,
        'product_id' => $product_id
    ]);

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
