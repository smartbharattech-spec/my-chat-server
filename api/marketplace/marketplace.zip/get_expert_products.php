<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET');

require_once '../config.php';

$expert_id = isset($_GET['expert_id']) ? (int)$_GET['expert_id'] : 0;

if (!$expert_id) {
    echo json_encode(['status' => 'error', 'message' => 'Expert ID is required']);
    exit;
}

try {
    $stmt = $pdo->prepare("SELECT * FROM marketplace_products WHERE expert_id = ? AND status = 'active' ORDER BY created_at DESC");
    $stmt->execute([$expert_id]);
    $products = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode([
        'status' => 'success',
        'products' => $products
    ]);

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
