<?php
header('Content-Type: application/json');
require_once '../config.php';

$input = json_decode(file_get_contents("php://input"), true);
$user_id = isset($input['user_id']) ? (int)$input['user_id'] : 0;
$expert_id = isset($input['expert_id']) ? (int)$input['expert_id'] : 0;
$conversation_id = isset($input['conversation_id']) ? (int)$input['conversation_id'] : 0;
$message = isset($input['message']) ? trim($input['message']) : '';

if (!$user_id || (!$expert_id && !$conversation_id) || empty($message)) {
    echo json_encode(['status' => 'error', 'message' => 'Sender ID, Message, and either Expert ID or Conversation ID are required.']);
    exit;
}

try {
    $pdo->beginTransaction();

    // 1. Get or create conversation
    if (!$conversation_id) {
        $stmt = $pdo->prepare("SELECT id FROM chat_conversations WHERE (user_id = ? AND expert_id = ?) OR (user_id = ? AND expert_id = ?)");
        $stmt->execute([$user_id, $expert_id, $expert_id, $user_id]);
        $existing = $stmt->fetch();

        if ($existing) {
            $conversation_id = $existing['id'];
        } else {
            $stmt = $pdo->prepare("INSERT INTO chat_conversations (user_id, expert_id, last_message) VALUES (?, ?, ?)");
            $stmt->execute([$user_id, $expert_id, $message]);
            $conversation_id = $pdo->lastInsertId();
        }
    }

    // 2. Insert message
    $stmt = $pdo->prepare("INSERT INTO chat_messages (conversation_id, sender_id, message) VALUES (?, ?, ?)");
    $stmt->execute([$conversation_id, $user_id, $message]);
    $message_id = $pdo->lastInsertId();

    // 3. Update conversation last message
    $stmt = $pdo->prepare("UPDATE chat_conversations SET last_message = ? WHERE id = ?");
    $stmt->execute([$message, $conversation_id]);

    $pdo->commit();

    echo json_encode([
        'status' => 'success',
        'data' => [
            'message_id' => $message_id,
            'conversation_id' => $conversation_id,
            'created_at' => date('Y-m-d H:i:s')
        ]
    ]);

} catch (Exception $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
