<?php
header('Content-Type: application/json');
header('Access-Control-Allow-Origin: *');

require_once '../config.php';

$slug = isset($_GET['slug']) ? trim($_GET['slug']) : '';

if (empty($slug)) {
    echo json_encode(['status' => 'error', 'message' => 'Slug is required.']);
    exit;
}

try {
    $stmt = $pdo->prepare("
        SELECT m.id as user_id, m.name, m.email, m.city, m.state, e.primary_skill, e.experience_years, 
               e.bio, e.expert_type, e.is_verified, e.expertise_tags, 
               e.custom_details, e.intro_video_url, e.slug,
               e.profile_image, e.banner_image, e.is_live,
               e.hourly_rate, e.languages
        FROM marketplace_users m
        JOIN expert_profiles e ON m.id = e.user_id
        WHERE e.slug = ? AND m.status = 'active'
    ");
    $stmt->execute([$slug]);
    $profile = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($profile) {
        echo json_encode(['status' => 'success', 'profile' => $profile]);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Profile not found or currently inactive.']);
    }

} catch (PDOException $e) {
    echo json_encode(['status' => 'error', 'message' => 'Database error: ' . $e->getMessage()]);
}
?>
