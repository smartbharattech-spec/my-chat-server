<?php
header('Content-Type: application/json');
require_once '../config.php';

$data = json_decode(file_get_contents('php://input'), true);

$order_id = isset($data['order_id']) ? (int)$data['order_id'] : 0;
$status = isset($data['status']) ? $data['status'] : '';
$user_id = isset($data['user_id']) ? (int)$data['user_id'] : 0;
$role = isset($data['role']) ? $data['role'] : 'user';

if (!$order_id || !$status || !$user_id) {
    echo json_encode(['status' => 'error', 'message' => 'Missing required details.']);
    exit;
}

try {
    $pdo->beginTransaction();

    // Fetch order details to verify
    $stmt = $pdo->prepare("SELECT * FROM marketplace_orders WHERE id = ?");
    $stmt->execute([$order_id]);
    $order = $stmt->fetch();

    if (!$order) {
        throw new Exception("Order not found.");
    }

    // Role-based status updates
    // Seeker can only mark as 'delivered'
    if ($role === 'user' && $status !== 'delivered') {
        throw new Exception("Users can only mark orders as delivered.");
    }
    
    // Admin can do anything
    // Expert can only see (for now) but maybe mark as shipped?
    
    $stmt = $pdo->prepare("UPDATE marketplace_orders SET status = ? WHERE id = ?");
    $stmt->execute([$status, $order_id]);

    // WALLET LOGIC: If status changed to 'delivered', add funds to expert wallet
    if ($status === 'delivered' && $order['status'] !== 'delivered') {
        $expert_id = $order['expert_id'];
        $amount = $order['amount'];

        // Ensure wallet exists
        $stmt = $pdo->prepare("INSERT IGNORE INTO expert_wallets (expert_id) VALUES (?)");
        $stmt->execute([$expert_id]);

        // Update wallet balance
        $stmt = $pdo->prepare("UPDATE expert_wallets SET balance = balance + ?, total_earned = total_earned + ? WHERE expert_id = ?");
        $stmt->execute([$amount, $amount, $expert_id]);

        // Get wallet ID for transaction log
        $stmt = $pdo->prepare("SELECT id FROM expert_wallets WHERE expert_id = ?");
        $stmt->execute([$expert_id]);
        $wallet = $stmt->fetch();

        // Log transaction
        $stmt = $pdo->prepare("INSERT INTO wallet_transactions (wallet_id, amount, type, order_id, description) VALUES (?, ?, 'credit', ?, ?)");
        $stmt->execute([$wallet['id'], $amount, $order_id, "Earnings from order #$order_id"]);
    }

    $pdo->commit();
    echo json_encode(['status' => 'success', 'message' => "Order status updated to $status."]);
} catch (Exception $e) {
    $pdo->rollBack();
    echo json_encode(['status' => 'error', 'message' => 'Failed to update order: ' . $e->getMessage()]);
}
?>
