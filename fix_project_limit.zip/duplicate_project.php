<?php
error_reporting(E_ALL);
ini_set('display_errors', 0);
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}

require_once 'config.php';

$data = json_decode(file_get_contents("php://input"), true);
$project_id = $data['project_id'] ?? null;
$email = $data['email'] ?? null;

if (!$project_id || !$email) {
    echo json_encode(["status" => "error", "message" => "Project ID and Email are required."]);
    exit;
}

try {
    // 1. Fetch the Original Project
    $stmt = $pdo->prepare("SELECT * FROM projects WHERE id = ? AND email = ?");
    $stmt->execute([$project_id, $email]);
    $original = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$original) {
        echo json_encode(["status" => "error", "message" => "Original project not found."]);
        exit;
    }

    // 2. CHECK LIMITS (Same logic as projects.php creation)
    $uStmt = $pdo->prepare("SELECT plan, plan_id, plan_expiry, plan_activated_at FROM users WHERE email = ?");
    $uStmt->execute([$email]);
    $user = $uStmt->fetch(PDO::FETCH_ASSOC);

    $plan = null;
    if ($user && ($user['plan_id'] || $user['plan'])) {
        $pStmt = $pdo->prepare("SELECT plan_type, credits, validity_days FROM plans WHERE id = ? OR title = ?");
        $pStmt->execute([$user['plan_id'] ?? -1, $user['plan'] ?? '']);
        $plan = $pStmt->fetch(PDO::FETCH_ASSOC);
    }

    if ($user && ($user['plan_id'] || $user['plan']) && $plan) {
        $userPlanId = $user['plan_id'];
        $userPlanTitle = $user['plan'];

        if ($plan['plan_type'] === 'subscription' && $user['plan_activated_at']) {
            $countStmt = $pdo->prepare("SELECT COUNT(*) as count FROM projects WHERE email = ? AND created_at >= ?");
            $countStmt->execute([$email, $user['plan_activated_at']]);
        } else {
            $countStmt = $pdo->prepare("SELECT COUNT(*) as count FROM projects WHERE email = ? AND (plan_id = ? OR plan_name = ?)");
            $countStmt->execute([$email, $userPlanId ?: -1, $userPlanTitle ?: '']);
        }

        $currentCount = $countStmt->fetch(PDO::FETCH_ASSOC)['count'];
        if ($currentCount >= $plan['credits'] && $plan['credits'] > 0) {
            echo json_encode(["status" => "error", "message" => "Limit Reached: Cannot duplicate. You have reached the project limit (" . $plan['credits'] . ") for your current plan."]);
            exit;
        }
    }

    // 3. Handle Map Image Copy
    $new_map_image = null;
    if (!empty($original['map_image'])) {
        $upload_dir = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'maps' . DIRECTORY_SEPARATOR;
        $old_filename = $original['map_image'];
        $extension = pathinfo($old_filename, PATHINFO_EXTENSION);
        $new_filename = "map_copy_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $extension;

        if (file_exists($upload_dir . $old_filename)) {
            if (copy($upload_dir . $old_filename, $upload_dir . $new_filename)) {
                $new_map_image = $new_filename;
            }
        }
    }

    // 4. Insert New Project
    $new_name = $original['project_name'] . " (Copy)";
    $stmt = $pdo->prepare("INSERT INTO projects (email, project_name, construction_type, plan_name, plan_id, map_image, project_data) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $original['email'],
        $new_name,
        $original['construction_type'],
        $original['plan_name'],
        $original['plan_id'],
        $new_map_image,
        $original['project_data']
    ]);

    echo json_encode([
        "status" => "success",
        "message" => "Project duplicated successfully as '$new_name'",
        "id" => $pdo->lastInsertId()
    ]);

} catch (PDOException $e) {
    echo json_encode(["status" => "error", "message" => "Database error: " . $e->getMessage()]);
}
?>