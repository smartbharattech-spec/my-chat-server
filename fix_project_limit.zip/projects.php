<?php
error_reporting(E_ALL);
error_reporting(E_ALL);
ini_set('display_errors', 0); // Disable error output to client to prevent JSON corruption
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS");
header("Access-Control-Allow-Headers: Content-Type, Access-Control-Allow-Headers, Authorization, X-Requested-With");
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    exit;
}
require_once 'config.php';
$method = $_SERVER['REQUEST_METHOD'];
switch ($method) {
    case 'GET':
        $action = $_GET['action'] ?? 'list';
        $email = $_GET['email'] ?? null;
        $project_name = $_GET['project_name'] ?? null;
        if ($action === 'check') {
            // Check if plan exists for email + project
            $id = $_GET['id'] ?? null;
            if (empty($email) || (empty($project_name) && empty($id))) {
                echo json_encode(["status" => "error", "message" => "Email and (project_name or id) are required for check"]);
                break;
            }
            try {
                if ($id) {
                    $stmt = $pdo->prepare("SELECT id, plan_id, plan_name, project_data, project_name, construction_type, map_image, project_issue FROM projects WHERE email = :email AND id = :id LIMIT 1");
                    $stmt->execute(['email' => $email, 'id' => $id]);
                } else {
                    $stmt = $pdo->prepare("SELECT id, plan_id, plan_name, project_data, project_name, construction_type, map_image, project_issue FROM projects WHERE email = :email AND project_name = :project_name LIMIT 1");
                    $stmt->execute(['email' => $email, 'project_name' => $project_name]);
                }
                $project = $stmt->fetch();
                if ($project) {
                    echo json_encode([
                        "status" => "success",
                        "purchased" => true, // Technically any project found is valid now, UI handles plan_id
                        "plan_id" => $project['plan_id'],
                        "plan_name" => $project['plan_name'],
                        "project_id" => $project['id'],
                        "project_data" => $project['project_data'],
                        "project_name" => $project['project_name'],
                        "construction_type" => $project['construction_type'],
                        "map_image" => $project['map_image'],
                        "project_issue" => $project['project_issue']
                    ]);
                } else {
                    echo json_encode(["status" => "success", "purchased" => false]);
                }
            } catch (PDOException $e) {
                echo json_encode(["status" => "error", "message" => $e->getMessage()]);
            }
        } else {
            // Fetch projects with pagination and filters
            try {
                $page = isset($_GET['page']) ? (int) $_GET['page'] : 1;
                $limit = isset($_GET['limit']) ? (int) $_GET['limit'] : 10;
                $offset = ($page - 1) * $limit;

                $search = isset($_GET['search']) ? trim($_GET['search']) : '';
                $startDate = isset($_GET['start_date']) ? $_GET['start_date'] : '';
                $endDate = isset($_GET['end_date']) ? $_GET['end_date'] : '';
                $status = isset($_GET['status']) ? $_GET['status'] : 'all';
                $constructionType = isset($_GET['construction_type']) ? $_GET['construction_type'] : 'all';

                $conditions = [];
                $params = [];

                if ($email) {
                    $conditions[] = "email = :email";
                    $params[':email'] = $email;
                }

                if (!empty($search)) {
                    $conditions[] = "(project_name LIKE :search OR plan_name LIKE :search)";
                    $params[':search'] = "%$search%";
                }

                if (!empty($startDate)) {
                    $conditions[] = "DATE(created_at) >= :startDate";
                    $params[':startDate'] = $startDate;
                }

                if (!empty($endDate)) {
                    $conditions[] = "DATE(created_at) <= :endDate";
                    $params[':endDate'] = $endDate;
                }

                if ($status === 'paid') {
                    $conditions[] = "(plan_id IS NOT NULL AND plan_id != '')";
                } elseif ($status === 'unpaid') {
                    $conditions[] = "(plan_id IS NULL OR plan_id = '')";
                }

                if ($constructionType !== 'all') {
                    $conditions[] = "construction_type = :constructionType";
                    $params[':constructionType'] = $constructionType;
                }

                $whereClause = "";
                if (count($conditions) > 0) {
                    $whereClause = "WHERE " . implode(" AND ", $conditions);
                }

                // Total Count
                $countSql = "SELECT COUNT(*) as total FROM projects $whereClause";
                $countStmt = $pdo->prepare($countSql);
                foreach ($params as $key => $val) {
                    $countStmt->bindValue($key, $val);
                }
                $countStmt->execute();
                $totalResult = $countStmt->fetch(PDO::FETCH_ASSOC);
                $totalProjects = $totalResult['total'];

                // Data
                $sql = "SELECT p.*, 
                               COALESCE(pl.plan_type, pl2.plan_type) as project_plan_type,
                               (SELECT status FROM payments WHERE (project_id = p.id OR (email = p.email AND plan_id = p.plan_id AND status = 'Pending')) AND status != 'Inactive' ORDER BY id DESC LIMIT 1) as payment_status
                        FROM projects p 
                        LEFT JOIN plans pl ON p.plan_id = pl.id 
                        LEFT JOIN plans pl2 ON p.plan_name = pl2.title 
                        $whereClause 
                        ORDER BY p.created_at DESC 
                        LIMIT :limit OFFSET :offset";
                $stmt = $pdo->prepare($sql);
                foreach ($params as $key => $val) {
                    $stmt->bindValue($key, $val);
                }
                $stmt->bindValue(':limit', $limit, PDO::PARAM_INT);
                $stmt->bindValue(':offset', $offset, PDO::PARAM_INT);
                $stmt->execute();
                $projects = $stmt->fetchAll(PDO::FETCH_ASSOC);

                echo json_encode([
                    "status" => "success",
                    "data" => $projects,
                    "total" => $totalProjects,
                    "page" => $page,
                    "limit" => $limit,
                    "total_pages" => ceil($totalProjects / $limit)
                ]);
            } catch (PDOException $e) {
                echo json_encode(["status" => "error", "message" => $e->getMessage()]);
            }
        }
        break;
    case 'POST':
        // Create new project
        $data = json_decode(file_get_contents("php://input"), true);
        if (empty($data['email']) || empty($data['project_name'])) {
            echo json_encode(["status" => "error", "message" => "Email and project_name are required"]);
            break;
        }

        try {
            // 1. Fetch User's Current Plan details
            $uStmt = $pdo->prepare("SELECT plan, plan_id, plan_expiry, plan_activated_at FROM users WHERE email = ?");
            $uStmt->execute([$data['email']]);
            $user = $uStmt->fetch(PDO::FETCH_ASSOC);

            // 2. Fetch Plan Details (if user has a plan)
            $plan = null;
            if ($user && ($user['plan_id'] || $user['plan'])) {
                $pStmt = $pdo->prepare("SELECT id, title, plan_type, credits, validity_days FROM plans WHERE id = ? OR title = ?");
                $pStmt->execute([$user['plan_id'] ?? -1, $user['plan'] ?? '']);
                $plan = $pStmt->fetch(PDO::FETCH_ASSOC);
            }

            $useSinglePaymentId = null;
            $creationPlanName = $data['plan_name'] ?? ($user['plan'] ?? null);
            $creationPlanId = $data['plan_id'] ?? ($user ? ($user['plan_id'] ?: null) : null);

            // 3. Credit Check & Single Purchase Fallback
            if ($user && ($user['plan_id'] || $user['plan']) && $plan) {
                $userPlanTitle = $user['plan'];
                $userPlanId = $user['plan_id'];

                if ($plan['plan_type'] === 'subscription' && $user['plan_activated_at']) {
                    // Count projects created after activation, BUT EXCLUDE those that are tied to a SINGLE PLAN purchase
                    // We check if the project's assigned plan is 'single'
                    $countStmt = $pdo->prepare("
                        SELECT COUNT(*) as count 
                        FROM projects p
                        LEFT JOIN plans pl ON p.plan_id = pl.id
                        LEFT JOIN plans pl2 ON p.plan_name = pl2.title
                        WHERE p.email = ? 
                        AND p.created_at >= ?
                        AND (pl.plan_type != 'single' OR pl.plan_type IS NULL)
                        AND (pl2.plan_type != 'single' OR pl2.plan_type IS NULL)
                    ");
                    $countStmt->execute([$data['email'], $user['plan_activated_at']]);
                } else {
                    // For single purchase, count projects explicitly tied to THIS plan (by ID or Title)
                    $countStmt = $pdo->prepare("SELECT COUNT(*) as count FROM projects WHERE email = ? AND (plan_id = ? OR plan_name = ?)");
                    $countStmt->execute([$data['email'], $userPlanId ?: -1, $userPlanTitle ?: '']);
                }

                $currentProjectsCount = $countStmt->fetch(PDO::FETCH_ASSOC)['count'];

                if ($currentProjectsCount >= $plan['credits'] && $plan['credits'] > 0) {
                    // PRIMARY PLAN EXHAUSTED - LOOK FOR UNUSED SINGLE PURCHASES
                    $sStmt = $pdo->prepare("SELECT id, plan, plan_id FROM payments WHERE email = ? AND status = 'Active' AND purchase_type = 'single_purchase' AND project_id IS NULL LIMIT 1");
                    $sStmt->execute([$data['email']]);
                    $unusedPayment = $sStmt->fetch(PDO::FETCH_ASSOC);

                    if ($unusedPayment) {
                        $useSinglePaymentId = $unusedPayment['id'];
                        $creationPlanName = $unusedPayment['plan'];
                        $creationPlanId = $unusedPayment['plan_id'];
                    } elseif (isset($data['plan_name'])) {
                        // USER IS ABOUT TO PURCHASE A SINGLE PLAN - ALLOW CREATION
                        // This project will be effectively "Unpaid" until payment is approved
                        $creationPlanName = $data['plan_name'];
                        $creationPlanId = $data['plan_id'] ?? null;
                    } else {
                        echo json_encode(["status" => "error", "message" => "You have reached the project limit (" . $plan['credits'] . ") for your current plan."]);
                        break;
                    }
                }
            } elseif (isset($data['plan_name'])) {
                // NO CURRENT PLAN, BUT PURCHASING ONE - ALLOW CREATION
                $creationPlanName = $data['plan_name'];
                $creationPlanId = $data['plan_id'] ?? null;
            }

            // 5. Check if follow-up is enabled for this plan
            $f_status = 'none';
            $f_start = null;
            if ($creationPlanId || $creationPlanName) {
                $fCheckStmt = $pdo->prepare("SELECT followup_enabled FROM plans WHERE id = ? OR title = ?");
                $fCheckStmt->execute([$creationPlanId ?? -1, $creationPlanName ?? '']);
                $fPlan = $fCheckStmt->fetch();
                if ($fPlan && (int) ($fPlan['followup_enabled'] ?? 0) === 1) {
                    $f_status = 'pending';
                    // Use user's plan activation date if available, otherwise current time
                    $f_start = ($user && $user['plan_activated_at']) ? $user['plan_activated_at'] : date('Y-m-d H:i:s');
                }
            }

            // 6. Proceed with creation
            $stmt = $pdo->prepare("INSERT INTO projects (email, project_name, construction_type, project_issue, plan_name, plan_id, project_data, followup_status, followup_start_at) VALUES (:email, :project_name, :construction_type, :project_issue, :plan_name, :plan_id, :project_data, :followup_status, :followup_start_at)");
            $stmt->execute([
                'email' => $data['email'],
                'project_name' => $data['project_name'],
                'construction_type' => $data['construction_type'] ?? 'Existing',
                'project_issue' => $data['project_issue'] ?? null,
                'plan_name' => $creationPlanName,
                'plan_id' => $creationPlanId,
                'project_data' => $data['project_data'] ?? null,
                'followup_status' => $f_status,
                'followup_start_at' => $f_start
            ]);
            $newProjectId = $pdo->lastInsertId();

            // 6. If we used a single payment slot, bind it to this project
            if ($useSinglePaymentId) {
                $upStmt = $pdo->prepare("UPDATE payments SET project_id = ? WHERE id = ?");
                $upStmt->execute([$newProjectId, $useSinglePaymentId]);
            }

            echo json_encode(["status" => "success", "message" => "Project created successfully", "id" => $newProjectId]);
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
        break;
    case 'PUT':
        // Update project
        $data = json_decode(file_get_contents("php://input"), true);

        if (empty($data['id'])) {
            echo json_encode(["status" => "error", "message" => "Project ID is required"]);
            break;
        }

        $project_id = $data['id'];
        $map_image_filename = null;

        // 🖼️ EXTRACT IMAGE FROM project_data IF PRESENT
        if (isset($data['project_data'])) {
            $project_state = json_decode($data['project_data'], true);

            if ($project_state && isset($project_state['image']) && strpos($project_state['image'], 'data:image') === 0) {
                $base64_string = $project_state['image'];

                // Extract extension and data
                if (preg_match('/^data:image\/(\w+);base64,/', $base64_string, $type)) {
                    $image_data = substr($base64_string, strpos($base64_string, ',') + 1);
                    $image_data = base64_decode($image_data);
                    $extension = strtolower($type[1]);

                    if ($image_data) {
                        // Generate Unique Name
                        $filename = "map_" . $project_id . "_" . time() . "_" . bin2hex(random_bytes(4)) . "." . $extension;
                        $upload_dir = __DIR__ . DIRECTORY_SEPARATOR . 'uploads' . DIRECTORY_SEPARATOR . 'maps' . DIRECTORY_SEPARATOR;

                        if (!is_dir($upload_dir)) {
                            mkdir($upload_dir, 0777, true);
                        }

                        if (file_put_contents($upload_dir . $filename, $image_data)) {
                            $map_image_filename = $filename;

                            // 🧹 CLEANUP: Remove large image from JSON to keep DB light
                            unset($project_state['image']);
                            $data['project_data'] = json_encode($project_state);

                            // 🗑️ DELETE OLD FILE IF EXISTS
                            $stmt_old = $pdo->prepare("SELECT map_image FROM projects WHERE id = :id");
                            $stmt_old->execute(['id' => $project_id]);
                            $old_res = $stmt_old->fetch();
                            if ($old_res && !empty($old_res['map_image'])) {
                                $old_file_path = $upload_dir . $old_res['map_image'];
                                if (file_exists($old_file_path)) {
                                    @unlink($old_file_path);
                                }
                            }
                        }
                    }
                }
            }
        }

        // Allow partial updates
        $fields = [];
        $params = ['id' => $project_id];

        if ($map_image_filename) {
            $fields[] = "map_image = :map_image";
            $params['map_image'] = $map_image_filename;
        }
        if (isset($data['email'])) {
            $fields[] = "email = :email";
            $params['email'] = $data['email'];
        }
        if (isset($data['project_name'])) {
            $fields[] = "project_name = :project_name";
            $params['project_name'] = $data['project_name'];
        }
        if (isset($data['construction_type'])) {
            $fields[] = "construction_type = :construction_type";
            $params['construction_type'] = $data['construction_type'];
        }
        if (isset($data['project_issue'])) {
            $fields[] = "project_issue = :project_issue";
            $params['project_issue'] = $data['project_issue'];
        }
        if (isset($data['plan_name'])) {
            $fields[] = "plan_name = :plan_name";
            $params['plan_name'] = $data['plan_name'];
        }
        if (isset($data['plan_id'])) {
            $fields[] = "plan_id = :plan_id";
            $params['plan_id'] = $data['plan_id'];
        }
        if (isset($data['project_data'])) {
            $fields[] = "project_data = :project_data";
            $params['project_data'] = $data['project_data'];
        }
        if (empty($fields)) {
            echo json_encode(["status" => "error", "message" => "No fields provided to update"]);
            break;
        }
        try {
            $sql = "UPDATE projects SET " . implode(", ", $fields) . " WHERE id = :id";
            $stmt = $pdo->prepare($sql);
            $stmt->execute($params);

            echo json_encode(["status" => "success", "message" => "Project updated successfully"]);
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
        break;
    case 'DELETE':
        $data = json_decode(file_get_contents("php://input"), true);
        $id = $data['id'] ?? ($_GET['id'] ?? null);
        $ids = $data['ids'] ?? null;

        if (!$id && !$ids) {
            echo json_encode(["status" => "error", "message" => "Project ID or IDs are required"]);
            break;
        }

        try {
            if ($ids && is_array($ids)) {
                // Bulk Delete
                $placeholders = str_repeat('?,', count($ids) - 1) . '?';
                $stmt = $pdo->prepare("DELETE FROM projects WHERE id IN ($placeholders)");
                $stmt->execute($ids);
                echo json_encode(["status" => "success", "message" => count($ids) . " projects deleted successfully"]);
            } else {
                // Single Delete
                $stmt = $pdo->prepare("DELETE FROM projects WHERE id = ?");
                $stmt->execute([$id]);
                if ($stmt->rowCount() > 0) {
                    echo json_encode(["status" => "success", "message" => "Project deleted successfully"]);
                } else {
                    echo json_encode(["status" => "error", "message" => "Project not found"]);
                }
            }
        } catch (PDOException $e) {
            echo json_encode(["status" => "error", "message" => $e->getMessage()]);
        }
        break;
    default:
        echo json_encode(["status" => "error", "message" => "Method not allowed"]);
        break;
}
?>